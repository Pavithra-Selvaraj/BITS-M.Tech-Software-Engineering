from scapy.all import *

def icmp_request_listener(pkt):
    if ICMP in pkt and pkt[ICMP].type == 8:
        # Received an ICMP echo request packet
        print("Received ICMP echo request")
        print(f"Src: {pkt[IP].src} Dst: {pkt[IP].dst}")
        
        # Send a spoofed ICMP echo reply
        src = pkt[IP].dst
        dst = pkt[IP].src
        seq = pkt[ICMP].seq
        id = pkt[ICMP].id
        load = pkt.load
        print(f"Response: Src {dst} Dst {src} type 0 REPLY\n")
        reply = IP(src=src, dst=dst)/ICMP(type=0, id=id, seq=seq)/load
        send(reply, verbose=0)

# Start sniffing for ICMP echo requests
sniff(iface='br-881178f586f1', filter='icmp', prn=icmp_request_listener)

