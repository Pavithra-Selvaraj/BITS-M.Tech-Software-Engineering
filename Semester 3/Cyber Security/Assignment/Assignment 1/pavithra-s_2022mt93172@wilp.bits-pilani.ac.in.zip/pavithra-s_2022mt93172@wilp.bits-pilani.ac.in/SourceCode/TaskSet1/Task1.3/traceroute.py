from scapy.all import *

# Define the destination IP address
destination_ip = "8.8.8.8"

# Initialize TTL value
ttl = 1

while True:
    # Initializing an ICMP packet with the specified TTL
    packet = IP(dst=destination_ip, ttl=ttl) / ICMP()

    # Sending the packet
    response = sr1(packet, verbose=False)

    if response is None:
        # No response received, break the loop
        print("No Response Received")
        break

    # Print the IP address of the router
    print(f"Hop {ttl}: {response.src}")

    if response.src == destination_ip:
        # Reached the destination, break the loop
        print("Destination Reached")
        break

    # Increment TTL for the next packet
    ttl += 1

