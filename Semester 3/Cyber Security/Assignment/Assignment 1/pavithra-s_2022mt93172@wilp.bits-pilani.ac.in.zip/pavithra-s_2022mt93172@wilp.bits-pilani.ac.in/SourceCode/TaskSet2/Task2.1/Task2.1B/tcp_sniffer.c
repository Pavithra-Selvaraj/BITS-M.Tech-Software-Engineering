#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h> // For IP header structure
#include <netinet/tcp.h> // For TCP header structure
#include <arpa/inet.h>   // For ntohs function

void got_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet)
{
    struct ip *ip_header;
    struct tcphdr *tcp_header;

    // Assuming Ethernet frame with IPv4 payload
    ip_header = (struct ip *)(packet + 14); // Skip the Ethernet header
    tcp_header = (struct tcphdr *)(packet + 14 + (ip_header->ip_hl << 2)); // Skip IP header

    char source_ip[INET_ADDRSTRLEN];
    char dest_ip[INET_ADDRSTRLEN];

    // Convert source and destination IP addresses to human-readable format
    inet_ntop(AF_INET, &(ip_header->ip_src), source_ip, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, &(ip_header->ip_dst), dest_ip, INET_ADDRSTRLEN);

    printf("Source IP: %s\n", source_ip);
    printf("Destination IP: %s\n", dest_ip);
    printf("TCP Source Port: %d\n", ntohs(tcp_header->th_sport));
    printf("TCP Destination Port: %d\n",  ntohs(tcp_header->th_dport));
    printf("==================================\n");
}

int main()
{
    pcap_t *handle;
    char errbuf[PCAP_ERRBUF_SIZE];
    struct bpf_program fp;

    // For TCP packets with destination port range from 10 to 100
    char filter_exp[] = "tcp dst portrange 10-100";

    bpf_u_int32 net;

    handle = pcap_open_live("br-881178f586f1", BUFSIZ, 1, 1000, errbuf);
    if (handle == NULL)
    {
        fprintf(stderr, "pcap_open_live error: %s\n", errbuf);
        return 1;
    }

    pcap_compile(handle, &fp, filter_exp, 0, net);
    if (pcap_setfilter(handle, &fp) != 0)
    {
        pcap_perror(handle, "Error:");
        exit(EXIT_FAILURE);
    }

    pcap_loop(handle, -1, got_packet, NULL);
    pcap_close(handle);

    return 0;
}

