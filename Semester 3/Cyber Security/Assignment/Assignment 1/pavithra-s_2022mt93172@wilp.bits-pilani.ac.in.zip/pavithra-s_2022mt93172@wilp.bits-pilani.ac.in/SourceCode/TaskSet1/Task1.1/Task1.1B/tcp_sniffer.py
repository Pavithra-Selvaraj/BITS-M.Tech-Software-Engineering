#!/usr/bin/python

from scapy.all import *

def print_pkt(pkt):
	if pkt[TCP] is not None:
		print("TCP Packet=====")
		print(f"\tSource IP: {pkt[IP].src}")
		print(f"\tDestination IP: {pkt[IP].dst}")
		print(f"\tTCP Source port: {pkt[TCP].sport}")
		print(f"\tTCP Destination port: {pkt[TCP].dport}")

pkt = sniff(iface='br-881178f586f1', filter='tcp and src host 10.9.0.5 and port 23', prn=print_pkt)
