# Local DNS Attack Assignment

This README provides an organized overview of the directory structure for each local DNS attack task in the assignment.

## Directory Structure
The assigment includes a separate folder for each task. Within the folder, there is a source code python file and a task implementation report.

The structure is as follows:

- `Task1/` (Main folder for Task 1)
    - `direct_spoofing.py` 
    - `Task_Implementation.pdf`
- `Task2/` (Main folder for Task 2)
    - `spoofing_answer.py` 
    - `Task_Implementation.pdf`
- `Task3/` (Main folder for Task 3)
    - `spoofing_ns.py`
    - `Task_Implementation.pdf` 
- `Task4/` (Main folder for Task 4)
    - `spoofing_ns_domain.py`
    - `Task_Implementation.pdf`
- `Task5/` (Main folder for Task 5)
    - `spoofing_additional.py`
    - `Task_Implementation.pdf`
- `DNS_Spoofing_Main_Report.pdf`
- `README.md`

## Report

The assignment report, titled `DNS_Spoofing_Main_Report` contains the base setup done for the DNS spoofing tasks, including steps, commands, and relevant screenshots. 

For individual tasks, the report is present inside the task folder itself. 

## Usage

Navigate to the respective task folder to access the source code and task implementation documentation. The assignment reports will give for in-depth insights into each DNS spoofing task.
