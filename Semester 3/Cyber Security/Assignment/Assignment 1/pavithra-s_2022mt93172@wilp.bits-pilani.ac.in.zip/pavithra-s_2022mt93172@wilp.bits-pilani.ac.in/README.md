# Assignment README

This README provides an overview of the directory structure and locations of source code for each task in the assignment. It also includes the assignment report file.

## Directory Structure

The assignment is organized into the following directory structure:

- `SourceCode/`
  - `TaskSet1/`
    - `Task1.1/`
    - `Task1.1A/`
    - `Task1.1B/`
    - `Task1.2/`
    - `Task1.3/`
    - `Task1.4/`
  - `TaskSet2/`
    - `Task2.1/`
    - `Task2.1A/`
    - `Task2.1B/`
    - `Task2.1C/`
    - `Task2.2/`
    - `Task2.2A/`
    - `Task2.2B/`
    - `Task2.3/`
- `Report/`
  - `Assignment_Report.docx`
- README.md

## Report

The assignment report in word format, titled `Assignment_Report`, is located in the `Report/` directory.

It contains the following information:

- Details of the programs done in the assignment.
- A step-by-step process of the actions and commands executed.
- Relevant screenshots illustrating the assignment tasks and results.

## Source Code Locations

Here are the locations of source code files for each task:

### Lab Assignment Task Set 1: Using Scapy to Sniff and Spoof Packets

- **Task 1.1: Sniffing Packets**
  - `SourceCode/TaskSet1/Task1.1/` (Main folder for Task 1.1)
  - `SourceCode/TaskSet1/Task1.1A/` (Main folder for Task 1.1A)
  - `SourceCode/TaskSet1/Task1.1B/` (Main folder for Task 1.1B)

- **Task 1.2: Spoofing ICMP Packets**
  - `SourceCode/TaskSet1/Task1.2/` (Main folder for Task 1.2)

- **Task 1.3: Traceroute**
  - `SourceCode/TaskSet1/Task1.3/` (Main folder for Task 1.3)

- **Task 1.4: Sniffing and then Spoofing**
  - `SourceCode/TaskSet1/Task1.4/` (Main folder for Task 1.4)

### Lab Assignment Task Set 2: Writing Programs to Sniff and Spoof Packets

- **Task 2.1: Writing Packet Sniffing Program**
  - `SourceCode/TaskSet2/Task2.1/` (Main folder for Task 2.1)
  - `SourceCode/TaskSet2/Task2.1A/` (Main folder for Task 2.1A)
  - `SourceCode/TaskSet2/Task2.1B/` (Main folder for Task 2.1B)
  - `SourceCode/TaskSet2/Task2.1C/` (Main folder for Task 2.1C)

- **Task 2.2: Spoofing**
  - `SourceCode/TaskSet2/Task2.2/` (Main folder for Task 2.2)
  - `SourceCode/TaskSet2/Task2.2A/` (Main folder for Task 2.2A)
  - `SourceCode/TaskSet2/Task2.2B/` (Main folder for Task 2.2B)

- **Task 2.3: Sniff and then Spoof**
  - `SourceCode/TaskSet2/Task2.3/` (Main folder for Task 2.3)

## Usage

Navigate to the respective task folder to access the source code and related files for each task. The assignment report is located in the `Report/` directory.

Feel free to explore each task's source code and execute the programs as required for the assignment.