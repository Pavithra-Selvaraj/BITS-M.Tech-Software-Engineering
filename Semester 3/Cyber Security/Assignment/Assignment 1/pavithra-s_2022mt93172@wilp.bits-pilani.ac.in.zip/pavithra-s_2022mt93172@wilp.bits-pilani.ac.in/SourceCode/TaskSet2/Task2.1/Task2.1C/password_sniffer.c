#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h> // For IP header structure
#include <netinet/tcp.h> // For TCP header structure
#include <arpa/inet.h>   // For ntohs function
#include <ctype.h>       // For isprint function

void print_payload(const u_char *payload, int len) {
    const u_char *ch;
    ch = payload;
    printf("Payload: \n\t\t");

    for (int i = 0; i < len; i++) {
        if (isprint(*ch)) {
            if (len == 1) {
                printf("\t%c", *ch);
            } else {
                printf("%c", *ch);
            }
        }
        ch++;
    }
    printf("\n____________________________________________\n");
}

void got_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *packet)
{
    struct ip *ip_header;
    struct tcphdr *tcp_header;
    const char *payload;
    int size_ip;
    int size_tcp;
    int size_payload;

    // Assuming Ethernet frame with IPv4 payload
    ip_header = (struct ip *)(packet + 14); // Skip the Ethernet header
    tcp_header = (struct tcphdr *)(packet + 14 + ((int)(ip_header->ip_hl) << 2)); // Skip IP header

    size_ip = (ip_header->ip_hl) << 2; // IP header length in bytes
    size_tcp = (tcp_header->th_off) << 2; // TCP header length in bytes

    payload = (u_char *)(packet + 14 + size_ip + size_tcp);
    size_payload = ntohs(ip_header->ip_len) - (size_ip + size_tcp);

    char source_ip[INET_ADDRSTRLEN];
    char dest_ip[INET_ADDRSTRLEN];

    // Convert source and destination IP addresses to human-readable format
    inet_ntop(AF_INET, &(ip_header->ip_src), source_ip, INET_ADDRSTRLEN);
    inet_ntop(AF_INET, &(ip_header->ip_dst), dest_ip, INET_ADDRSTRLEN);
   if(size_payload > 0){
    printf("Source IP: %s\t", source_ip);
    printf("Destination IP: %s\n", dest_ip);
    printf("TCP Source Port: %d\t", ntohs(tcp_header->th_sport));
    printf("TCP Destination Port: %d\n", ntohs(tcp_header->th_dport));
    print_payload(payload, size_payload);
    }
}

int main()
{
    pcap_t *handle;
    char errbuf[PCAP_ERRBUF_SIZE];
    struct bpf_program fp;

    // For TCP packets with destination port range from 10 to 100
    char filter_exp[] = "tcp dst portrange 10-100";

    bpf_u_int32 net;

    handle = pcap_open_live("br-881178f586f1", BUFSIZ, 1, 1000, errbuf);
    if (handle == NULL)
    {
        fprintf(stderr, "pcap_open_live error: %s\n", errbuf);
        return 1;
    }

    pcap_compile(handle, &fp, filter_exp, 0, net);
    if (pcap_setfilter(handle, &fp) != 0)
    {
        pcap_perror(handle, "Error:");
        exit(EXIT_FAILURE);
    }

    pcap_loop(handle, -1, got_packet, NULL);
    pcap_close(handle);

    return 0;
}

